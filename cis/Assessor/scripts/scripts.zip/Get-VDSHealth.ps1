# Get VDS health checks
$Output =
	Get-VDSwitch |
	Select Name,
	@{N="VLAN";E={$_.ExtensionData.Config.HealthCheckConfig.Enable[0]}},
	@{N="Teaming";E={$_.ExtensionData.Config.HealthCheckConfig.Enable[1]}}
$Output | ConvertTo-Csv -NoTypeInformation